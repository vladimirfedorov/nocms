﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CodedView
{
    static class settings
    {
        public static Font FontFamily;
        public static Color ForeColor;
        public static Color BackgroundColor;
        public static bool WordWrap;

        private static string IniFilename()
        {
            return Application.ExecutablePath.TrimEnd(".exeEXE".ToCharArray()) + ".ini";
        }

        public static void ReadSettings()
        {
            Ini.IniFile inifile = new Ini.IniFile(IniFilename());
            string section = "Main";

            string tmp;

            // size 
            float FontSize = 10;
            tmp = inifile.IniReadValue(section, "FontSize", "10");
            float.TryParse(tmp, out FontSize);

            // face
            tmp = inifile.IniReadValue(section, "FontFamily", "Courier New");
            FontFamily = new Font(tmp, FontSize);

            // text color
            int color = 0;
            tmp = inifile.IniReadValue(section, "ForeColor", "000000");
            int.TryParse(tmp, System.Globalization.NumberStyles.HexNumber, null, out color);
            ForeColor = Color.FromArgb(255, Color.FromArgb(color));

            // background color
            color = 0xFFFFFF;
            tmp = inifile.IniReadValue(section, "BackgroundColor", "FFFFFF");
            int.TryParse(tmp, System.Globalization.NumberStyles.HexNumber, null, out color);
            BackgroundColor = Color.FromArgb(255, Color.FromArgb(color));



            // word-wrap
            tmp = inifile.IniReadValue(section, "WordWrap", "1");
            WordWrap = tmp == "1" ? true : false;
        }

        public static void WriteSettings()
        {
            Ini.IniFile inifile = new Ini.IniFile(IniFilename());
            string section = "Main";
            inifile.IniWriteValue(section, "FontSize", FontFamily.Size.ToString());
            inifile.IniWriteValue(section, "FontFamily", FontFamily.FontFamily.Name);
            inifile.IniWriteValue(section, "ForeColor", string.Format("{0,2}{1,2}{2,2}",
                ForeColor.R.ToString("X2"),
                ForeColor.G.ToString("X2"),
                ForeColor.B.ToString("X2")));
            inifile.IniWriteValue(section, "BackgroundColor", string.Format("{0,2}{1,2}{2,2}",
                BackgroundColor.R.ToString("X2"),
                BackgroundColor.G.ToString("X2"),
                BackgroundColor.B.ToString("X2")));
            inifile.IniWriteValue(section, "WordWrap", WordWrap ? "1" : "0");

        }

        public static void GetFont()
        {
            FontDialog dlg = new FontDialog();
            dlg.Font = FontFamily;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                FontFamily = dlg.Font;
                WriteSettings();
            }
        }

        public static void GetColor(ColorFor c)
        {
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                switch (c)
                {
                    case ColorFor.BackgroundColor: BackgroundColor = dlg.Color; break;
                    case ColorFor.ForeColor: ForeColor = dlg.Color; break;
                }
                WriteSettings();
            }

        }

        private static string MenuName = "txtfile\\shell\\open.CodedViewMenu";
        private static string Command = "txtfile\\shell\\open.CodedViewMenu\\command";
        private static string MenuText = "Open with CodedView";
        private static string MenuCommand = Application.ExecutablePath + " %1";

        public static void AddRegistryKeys()
        {
            RegistryKey regmenu = null;
            RegistryKey regcmd = null;
            try
            {
                regmenu = Registry.ClassesRoot.CreateSubKey(MenuName);
                if (regmenu != null)
                    regmenu.SetValue("", MenuText);
                regcmd = Registry.ClassesRoot.CreateSubKey(Command);
                if (regcmd != null)
                    regcmd.SetValue("", MenuCommand);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                if (regmenu != null)
                    regmenu.Close();
                if (regcmd != null)
                    regcmd.Close();
            }
        }

        public static bool IsRegistryKeysAccessible()
        {
            bool isAccessible = false;
            try
            {
                RegistryKey reg;
                reg = Registry.ClassesRoot.OpenSubKey(Command, RegistryKeyPermissionCheck.ReadWriteSubTree);
                reg.Close();
                reg = Registry.ClassesRoot.OpenSubKey(MenuName, RegistryKeyPermissionCheck.ReadWriteSubTree);
                reg.Close();
                isAccessible = true;
            }
            catch { }
            return isAccessible;
        }

        public static bool RegistryKeysExist()
        {
            bool exist = false;

            try
            {
                RegistryKey reg = Registry.ClassesRoot.OpenSubKey(Command);
                if (reg != null)
                {
                    exist = true;
                    reg.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return exist;
        }

        public static void RemoveRegistryKeys()
        {
            try
            {
                RegistryKey reg = Registry.ClassesRoot.OpenSubKey(Command);
                if (reg != null)
                {
                    reg.Close();
                    Registry.ClassesRoot.DeleteSubKey(Command);
                }
                reg = Registry.ClassesRoot.OpenSubKey(MenuName);
                if (reg != null)
                {
                    reg.Close();
                    Registry.ClassesRoot.DeleteSubKey(MenuName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }

    enum ColorFor { ForeColor, BackgroundColor };

}
