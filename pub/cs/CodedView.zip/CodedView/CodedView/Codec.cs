﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace CodedView
{
    class Codec
    {
        public static byte[] Encode(string Text, string Password)
        {
            return Encode(Encoding.Default.GetBytes(Text), Password);
        }

        public static byte[] Encode(byte[] Data, string Password)
        {
            
            byte[] key = MD5.Create().ComputeHash( Encoding.Default.GetBytes(Password));
            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.Key = key;
            aes.IV = key;
            ICryptoTransform ict = aes.CreateEncryptor();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            CryptoStream cs = new CryptoStream(ms, ict, CryptoStreamMode.Write);
            cs.Write(Data, 0, Data.Length);
            cs.FlushFinalBlock();

            byte[] result = ms.ToArray();
            return result;
        }

        public static string Decode(byte[] Data, string Password)
        {
            byte[] key = MD5.Create().ComputeHash(Encoding.Default.GetBytes(Password));
            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.Key = key;
            aes.IV = key;
            ICryptoTransform ict = aes.CreateDecryptor();
            System.IO.MemoryStream ms = new System.IO.MemoryStream(Data,0,Data.Length);
            CryptoStream cs = new CryptoStream(ms, ict, CryptoStreamMode.Read);

            string result = new System.IO.StreamReader(cs, Encoding.Default).ReadToEnd();
            return result;
        }

    }
}
