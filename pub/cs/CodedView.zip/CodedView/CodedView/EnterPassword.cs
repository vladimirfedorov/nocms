﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CodedView
{
    public partial class EnterPassword : Form
    {
        public string Password = ""; 

        public EnterPassword()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Password = PasswordBox.Text;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Password = "";
            this.Close();
        }

    }
}
