﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CodedView
{
    public partial class Editor : Form
    {
        // constructor

        public Editor()
        {
            InitializeComponent();

            settings.ReadSettings();
            UpdateEditorSettings();
            wordWrapToolStripMenuItem.Checked = settings.WordWrap;
            CheckArgs();
            UpdateCursorPosition();

            // depending on different rights
            try
            {
                if (settings.RegistryKeysExist())
                    addEplorerContextMenuToolStripMenuItem.Checked = true;
            }
            catch { }

            if (!settings.IsRegistryKeysAccessible())
                addEplorerContextMenuToolStripMenuItem.Enabled = false;
        }
        

        // My functions

        private string filename = "";
        private string Password = "";
        private bool isDirty = false;
        private string OpenFile = "";

        private bool IsDirty
        {
            get { return isDirty; }
            set
            {
                isDirty = value;
                statZ.Text = isDirty ? "!" : "";
            }
        }

        private string FileName
        {
            get
            {
                return filename;
            }

            set
            {
                filename = value;
                statFilename.Text = filename;
            }
        }

        private void UpdateMenuText()
        {
            System.Resources.ResourceManager resman = new System.Resources.ResourceManager(typeof(string));
            fileToolStripMenuItem.Text = resman.GetString("");
        }

        private void CheckFilename()
        {
            if (FileName == "")
            {
                SaveFileDialog dlg = new SaveFileDialog();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    FileName = dlg.FileName;
                }
            }
        }

        private void CheckPassword()
        {
            if (Password == "")
            {
                EnterPassword dlg = new EnterPassword();
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    Password = dlg.Password;
                }
            }
        }

        private void CheckIsDirty()
        {
            if (IsDirty)
            {
                if (MessageBox.Show("File is modified, do you want to save it?", "Exit",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Save();
                }
            }
        }

        private void CheckArgs()
        {
            string[] args = Environment.GetCommandLineArgs();
            if (args == null) return;
            if (args.Length < 2) return;

            if (System.IO.File.Exists(args[1]))
            {
                OpenFile = args[1];
                Open();
            }

        }

        private void CheckWordWrap()
        {
            if (wordWrapToolStripMenuItem.Checked)
            {
                EditorBox.WordWrap = true;
                EditorBox.ScrollBars = ScrollBars.Vertical;
            }
            else
            {
                EditorBox.WordWrap = false;
                EditorBox.ScrollBars = ScrollBars.Both;
            }
            settings.WordWrap = wordWrapToolStripMenuItem.Checked;
            settings.WriteSettings();
        }

        private void UpdateCursorPosition()
        {
            int curpos = EditorBox.SelectionStart;
            int row = EditorBox.Text.Substring(0, curpos).Split("\n".ToCharArray()).Length;
            int lastlf = EditorBox.Text.Substring(0, curpos).LastIndexOf("\n");
            int column = curpos - (lastlf == -1 ? 0 : lastlf) + (EditorBox.Text.Substring(0, curpos).Contains("\n") ? 0 : 1);
            statColumn.Text = "Column: " + column;
            statRow.Text = "Row: " + row;
        }

        private void Open()
        {
            CheckIsDirty();
            OpenFileDialog dlg = new OpenFileDialog();
            EnterPassword pwddlg = new EnterPassword();

            if (OpenFile == "")
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
            }

            if (pwddlg.ShowDialog() == DialogResult.OK)
            {
                if (OpenFile == "")
                {
                    FileName = dlg.FileName;
                }
                else
                {
                    FileName = OpenFile;
                }

                byte[] data = null;
                string contents = "";

                try
                {
                    data = System.IO.File.ReadAllBytes(FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening file " + FileName + ":\n" + ex.ToString(),
                        "File error", MessageBoxButtons.OK);
                }

                if (data != null)
                {
                    try
                    {
                        contents = Codec.Decode(data, pwddlg.Password);
                        EditorBox.Text = contents;
                        EditorBox.Select(0, 0);
                        IsDirty = false;
                        Password = pwddlg.Password;
                    }
                    catch
                    {
                        MessageBox.Show("Error decrypting file",
                            "Decrypting error", MessageBoxButtons.OK);

                        FileName = "";
                        Password = "";

                    }

                }
            }

            OpenFile = "";
            UpdateCursorPosition();
        }

        private void Save()
        {
            CheckFilename();

            if (FileName != "")
            {
                CheckPassword();

                if (Password != "")
                {
                    byte[] data = null;
                    try
                    {
                        data = Codec.Encode(EditorBox.Text, Password);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error encrypting file:\n" + ex.ToString(),
                            "Encrypting error", MessageBoxButtons.OK);
                    }

                    if (data != null)
                    {
                        try
                        {
                            System.IO.File.WriteAllBytes(FileName, data);
                            IsDirty = false;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving file " + FileName + ":\n" + ex.ToString(),
                                "File error", MessageBoxButtons.OK);
                        }
                    }
                }
            }
        }

        private void UpdateEditorSettings()
        {
            EditorBox.Font = settings.FontFamily;
            EditorBox.ForeColor = settings.ForeColor;
            EditorBox.BackColor = settings.BackgroundColor;
        }


        // Interface functions

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EditorBox_TextChanged(object sender, EventArgs e)
        {
            IsDirty = true;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Open();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void Editor_FormClosing(object sender, FormClosingEventArgs e)
        {
            CheckIsDirty();
        }

        private void aboutCodedViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aboutcv f = new aboutcv();
            f.ShowDialog();
        }

        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wordWrapToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            CheckWordWrap();
        }

        private void EditorBox_Click(object sender, EventArgs e)
        {
            UpdateCursorPosition();
        }

        private void EditorBox_KeyUp(object sender, KeyEventArgs e)
        {
            UpdateCursorPosition();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            settings.GetFont();
            UpdateEditorSettings();
        }

        private void textColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            settings.GetColor(ColorFor.ForeColor);
            UpdateEditorSettings();
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            settings.GetColor(ColorFor.BackgroundColor);
            UpdateEditorSettings();
        }

        private void addEplorerContextMenuToolStripMenuItem_CheckStateChanged(object sender, EventArgs e)
        {
            if (addEplorerContextMenuToolStripMenuItem.Checked)
            {
                if (!settings.RegistryKeysExist()) settings.AddRegistryKeys();
            }
            else
            {
                if (settings.RegistryKeysExist()) settings.RemoveRegistryKeys();
            }

            
        }

    }


}
