#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#include <stdio.h>
#include <math.h>

#define XRES 800
#define YRES 600
#define pi180 .0174532925199f

HGLRC hRC=NULL;
HWND hWnd=NULL;
HDC hDC=NULL;
HINSTANCE hInstance;
char ErrorMsg[]="Iitialization Failed,  ";

float heading;
bool keys[256],fullscreen,active,lp,bp,dp,fp,light=false,blend=true,depth=true,fog=false;
GLfloat xrot,yrot,zrot,a=.01f,z=-0.0f,xpos,zpos,walkbias=0,walkbiasangle=0,lookupdown=.0f,alpha=.5;
GLfloat ambientLight[]={.7f,.7f,.7f,1.0f},diffuseLight[]={.9f,.8f,.7f,1.0f},lightPosition[]={.0f,.0f,.0f,1.0f};
GLuint *texture;

typedef struct tVertex{
	float x,y,z;
} VERTEX;

typedef struct tPoly{
	VERTEX vertex[4];
	float ut,vt;
	int textureNumber,transparent;
} POLY;

typedef struct tSector{
	int numpolies;
	POLY *polygon;
} SECTOR;

typedef struct tNormal{
	float x,y,z;
}NORMAL;

SECTOR sector;
NORMAL normal;
 
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

void trim(char *str)
{
	if(str[0]==32){
		int i=0;
		while(str[++i]==32);
		for(int n=i;n<(512-i);n++)str[n-i]=str[i];
	}
	return;
}


void readstr(FILE *f, char *str)
{
	do {
		fgets(str,512,f);
//		trim(str);
	} while ((str[0]=='#')||(str[0]=='\n'));
	return;
}

bool loadTexture(char *bitmap, int number)
{	
	FILE *file=fopen(bitmap,"r");
	if(!file)return false;
	fclose(file);
	AUX_RGBImageRec *textureImg[1];
	memset(textureImg,0,sizeof(void *)*1);
	if(!(textureImg[0]=auxDIBImageLoad(bitmap)))return false;
	glBindTexture(GL_TEXTURE_2D,texture[number]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
//	glTexImage2D(GL_TEXTURE_2D,1,3,textureImg[0]->sizeX,textureImg[0]->sizeY,0,GL_RGB,GL_UNSIGNED_BYTE,textureImg[0]->data);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3,textureImg[0]->sizeX,textureImg[0]->sizeY,GL_RGB,GL_UNSIGNED_BYTE,textureImg[0]->data);
	free(textureImg[0]->data);
	free(textureImg[0]);
	return true;
}

bool readWorldMap(char *mapfile)
{
	FILE *file=fopen("data/world.txt","r");
	if(!file)return false;
	
	ErrorMsg[22]='B';
	char str[512];
	int texNumber;
	readstr(file,str);

	GLUquadric *sph=gluNewQuadric();
	gluSphere(sph,2,16,16);
	gluQuadricOrientation(sph,GLU_OUTSIDE);


	// 1st line is a number of polygons and a number of used textures
	sscanf(str,"%d %d",&sector.numpolies,&texNumber);
	texture=new GLuint[texNumber];
	glGenTextures(texNumber,&texture[0]);	// 2 texture
	sector.polygon=new POLY[sector.numpolies];
	for(int i=0;i<sector.numpolies;i++){
		readstr(file,str);
		sscanf(str,"%f %f %f  %f %f %f  %f %f %f  %f %f %f  %f %f %d %d",\
			&sector.polygon[i].vertex[0].x,&sector.polygon[i].vertex[0].y,&sector.polygon[i].vertex[0].z,\
			&sector.polygon[i].vertex[1].x,&sector.polygon[i].vertex[1].y,&sector.polygon[i].vertex[1].z,\
			&sector.polygon[i].vertex[2].x,&sector.polygon[i].vertex[2].y,&sector.polygon[i].vertex[2].z,\
			&sector.polygon[i].vertex[3].x,&sector.polygon[i].vertex[3].y,&sector.polygon[i].vertex[3].z,\
			&sector.polygon[i].ut,&sector.polygon[i].vt,&sector.polygon[i].textureNumber,&sector.polygon[i].transparent);
	}
	int texNum;
	char texName[256];
	for(i=0;i<texNumber;i++){
		readstr(file,str);
		sscanf(str,"%d %s",&texNum,texName);
		if(!loadTexture(texName,texNum))return false;
	}
	fclose(file);

	return true;

}

GLvoid resizeScene(GLsizei width, GLsizei height)
{	if(height==0)height=1;
	glViewport(0,0,width,height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,.1f,100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int initGL(GLvoid)
{	glEnable(GL_TEXTURE_2D);
	glFogf(GL_FOG_START,2);
	glFogf(GL_FOG_DENSITY,0.2f);
	float fc[4]={.7f,.5f,.5f,.5f};
	glFogfv(GL_FOG_COLOR,fc);
	if(fog)glEnable(GL_FOG);
	glShadeModel(GL_SMOOTH);
	glClearColor(.0f,.0f,.0f,.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
//	Lighting
	glLightfv(GL_LIGHT1,GL_AMBIENT,ambientLight);
	glLightfv(GL_LIGHT1,GL_DIFFUSE,diffuseLight);
	glLightfv(GL_LIGHT1,GL_POSITION,lightPosition);
	glEnable(GL_LIGHT1);
//	glEnable(GL_LIGHTING);
//	Blending
	glColor4f(.7f,.7f,.7f,.4f); //40%
	glBlendFunc(GL_ONE,GL_SRC_ALPHA);
//	glEnable(GL_BLEND);
//	glDisable(GL_DEPTH_TEST);
	if(!readWorldMap("data/world.txt"))return false;
	return true;
}

int drawScene(GLvoid)
{	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	float az=1.0, ay=.1;

	glRotatef(lookupdown,1.0f,.0f,.0f);
	glRotatef(360.0-yrot,.0f,1.0f,.0f);
	glTranslatef(-xpos,-walkbias,-zpos);
//	lightPosition[0]=xpos;	lightPosition[1]=walkbias;	lightPosition[2]=zpos;	lightPosition[3]=1.0f;
	lightPosition[0]=0;	lightPosition[1]=0;	lightPosition[2]=0;	lightPosition[3]=1.0f;
	glLightfv(GL_LIGHT1,GL_POSITION,lightPosition);

//	glRotatef(zrot,.0f,.0f,1.0f);

	for(int i=0;i<sector.numpolies;i++){
		glBindTexture(GL_TEXTURE_2D,texture[sector.polygon[i].textureNumber]);
			normal.x=sector.polygon[i].vertex[0].x+sector.polygon[i].vertex[1].x+sector.polygon[i].vertex[2].x+sector.polygon[i].vertex[3].x;
			normal.y=sector.polygon[i].vertex[0].y+sector.polygon[i].vertex[1].y+sector.polygon[i].vertex[2].y+sector.polygon[i].vertex[3].y;
			normal.z=sector.polygon[i].vertex[0].z+sector.polygon[i].vertex[1].z+sector.polygon[i].vertex[2].z+sector.polygon[i].vertex[3].z;
		if(sector.polygon[i].transparent){
			if(blend)glEnable(GL_BLEND);
			if(depth)glDisable(GL_DEPTH_TEST);
		}

		glBegin(GL_QUADS);
		glNormal3f(-normal.x,-normal.y,-normal.z);
		glTexCoord2f(.0f,.0f); glVertex3f(sector.polygon[i].vertex[0].x/az,sector.polygon[i].vertex[0].y/az-ay,sector.polygon[i].vertex[0].z/az);
		glTexCoord2f(sector.polygon[i].ut,.0f); glVertex3f(sector.polygon[i].vertex[1].x/az,sector.polygon[i].vertex[1].y/az-ay,sector.polygon[i].vertex[1].z/az);
		glTexCoord2f(sector.polygon[i].ut,sector.polygon[i].vt); glVertex3f(sector.polygon[i].vertex[2].x/az,sector.polygon[i].vertex[2].y/az-ay,sector.polygon[i].vertex[2].z/az);
		glTexCoord2f(.0f,sector.polygon[i].vt); glVertex3f(sector.polygon[i].vertex[3].x/az,sector.polygon[i].vertex[3].y/az-ay,sector.polygon[i].vertex[3].z/az);
		glEnd();

		if(sector.polygon[i].transparent){
			if(blend){glDisable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);}
		}

	}
//	glDisable(GL_BLEND);
//	glEnable(GL_DEPTH_TEST);

//	xrot+=a; if(xrot>30 || xrot<-30)a=-a;
//	yrot-=1.5f;
//	zrot-=0.0f;

	return true;
}

GLvoid closeWindow(GLvoid)
{
	if(fullscreen){
		ChangeDisplaySettings(NULL,0);
		ShowCursor(true);
	}
	if(hRC){
		if(!wglMakeCurrent(NULL,NULL))MessageBox(NULL,"Couldn't release DC and RC","Error",MB_OK|MB_ICONINFORMATION);
		if(!wglDeleteContext(hRC))MessageBox(NULL,"Couldn't release rendering context","Error",MB_OK|MB_ICONINFORMATION);
		hRC=NULL;
	}
	if(hDC&&!ReleaseDC(hWnd,hDC)){
		MessageBox(NULL,"Couldn't release device context","Error",MB_OK|MB_ICONINFORMATION);
		hDC=NULL;
	}
	if(hWnd&&!DestroyWindow(hWnd)){
		MessageBox(NULL,"Couldn't destroy window","Error",MB_OK|MB_ICONINFORMATION);
		hWnd=NULL;
	}
	if(!UnregisterClass("OpenGL",hInstance)){
		MessageBox(NULL,"Couldn't unregister class 'OpenGL'","Error",MB_OK|MB_ICONINFORMATION);
		hInstance=NULL;
	}
}

BOOL createWindow(char* caption, int width, int height, int bits)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values

	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height


	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=false;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return false;
			}
		}
	}

	if (fullscreen)
	{
		dwExStyle=WS_EX_APPWINDOW;
		dwStyle=WS_POPUP;
		ShowCursor(false);
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle=WS_OVERLAPPEDWINDOW;
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								caption,							// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		closeWindow();
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))
	{
		closeWindow();
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))
	{
		closeWindow();
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))
	{
		closeWindow();
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				
	{
		closeWindow();
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					
	{
		closeWindow();								
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								
	}

	ShowWindow(hWnd,SW_SHOW);						
	SetForegroundWindow(hWnd);						
	SetFocus(hWnd);									
	resizeScene(width, height);						

	if (!initGL())									
	{
		closeWindow();								
		//MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		MessageBox(NULL,ErrorMsg,"ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								
	}

	return true;									
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)		
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
			if (!HIWORD(wParam))active=true; else active=false;
			return 0;								// Return To The Message Loop

		case WM_SYSCOMMAND:							// Intercept System Commands
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit

		case WM_CLOSE:								// Did We Receive A Close Message?
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back

		case WM_KEYDOWN:							// Is A Key Being Held Down?
			keys[wParam] = true;					// If So, Mark It As TRUE
			return 0;								// Jump Back

		case WM_KEYUP:								// Has A Key Been Released?
			keys[wParam] = false;					// If So, Mark It As FALSE
			return 0;								// Jump Back

		case WM_SIZE:								// Resize The OpenGL Window
			resizeScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
	}

	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{			
	MSG		msg;									// Windows Message Structure
	BOOL	done=false;								// Bool Variable To Exit Loop

	MessageBox(NULL,"How to use:\n\
[F1] toggles fullscreen mode / windowed mode\n\
[<-] rotate left\n\
[->] rotate right\n\
[Cursor UP] walk forward\n\
[Cursor DOWN] walk backward\n\
[PAGE UP] look up\n\
[PAGE DOWN] look down\n\
[END] look forward\n\
[L] light on/off, [B] blending on/off, [T] depthtest on/off\n\
[ESC] exit\n","Instructions:",MB_OK|MB_ICONINFORMATION);
	
	if (MessageBox(NULL,"Start fullscreen?", "Start fullscreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)fullscreen=false;else fullscreen=true;							

	if (!createWindow("OpenGL Test",XRES,YRES,16))return 0;
	
	while(!done)									
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	
		{
			if (msg.message==WM_QUIT)				
			{	done=true;
			}
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else										
		{
			
			if (active){
				if (keys[VK_ESCAPE]){
					done=true;						// ESC Signalled A Quit
				}
				else								// Not Time To Quit, Update Screen
				{
					drawScene();					// Draw The Scene
					SwapBuffers(hDC);				// Swap Buffers (Double Buffering)
				}
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=false;					// If So Make Key FALSE
				closeWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!createWindow("OpenGL Test",XRES,YRES,16))
				{
					return 0;						// Quit If Window Was Not Created
				}
			}

			if(keys['L']&&!lp){
				lp=true;
				light=!light;
				if(light)glEnable(GL_LIGHTING);else glDisable(GL_LIGHTING);
			}
			if(!keys['L'])lp=false;
			
			if(keys['B']&&!bp){
				bp=true;
				blend=!blend;
				if(blend){glEnable(GL_BLEND);glDisable(GL_DEPTH_TEST);}
				else{glDisable(GL_BLEND);glEnable(GL_DEPTH_TEST);}
			}
			if(!keys['B'])bp=false;

			if(keys['T']&&!dp){
				dp=true;
				depth=!depth;
			}
			if(!keys['T'])dp=false;

			if(keys['F']&&!fp){
				fp=true;
				fog=!fog;
				if(fog)glEnable(GL_FOG);else glDisable(GL_FOG);
			}
			if(!keys['F'])fp=false;

			if(keys[VK_UP]|keys['W']){
				xpos-=(float)sin(heading*pi180)*.05f;
				zpos-=(float)cos(heading*pi180)*.05f;
				if(walkbiasangle>=359.0f) walkbiasangle=.0f; else walkbiasangle+=10;
				walkbias=(float)sin(walkbiasangle*pi180)/20.0f;
			}
			if(keys[VK_DOWN]|keys['S']){
				xpos+=(float)sin(heading*pi180)*.05f;
				zpos+=(float)cos(heading*pi180)*.05f;
				if(walkbiasangle<=1.0f) walkbiasangle=359.0f; else walkbiasangle-=10;
				walkbias=(float)sin(walkbiasangle*pi180)/20.0f;
			}
			
			if(keys['A']){
				xpos-=(float)cos(yrot*pi180)*.05f;
				zpos+=(float)sin(yrot*pi180)*.05f;
			}
			if(keys['D']){
				xpos+=(float)cos(yrot*pi180)*.05f;
				zpos-=(float)sin(yrot*pi180)*.05f;
			}

			if(keys[VK_LEFT]){
				heading+=2.0f;
				yrot=heading;
			}
			if(keys[VK_RIGHT]){
				heading-=2.0f;
				yrot=heading;
			}
			if(keys[VK_PRIOR])lookupdown-= 1.0f;
			if(keys[VK_NEXT])lookupdown+= 1.0f;
			if(keys[VK_END])lookupdown=0;

			//if(keys['A'])z+=.1f;
			if(keys['X'])gluLookAt(0,0,0,.1,.1,.1,.2,.2,.2);
			
		}
	}

	// Shutdown
	closeWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
