#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#include <stdio.h>

#define XRES 800
#define YRES 600

HGLRC hRC=NULL;
HWND hWnd=NULL;
HDC hDC=NULL;
HINSTANCE hInstance;

bool keys[256],fullscreen,active,lp,bp,light=true,blend=true;
GLfloat xrot=-9,yrot=-20,zrot,a=.1f,z=-6.0f;
GLfloat ambientLight[]={.6f,.6f,.6f,1.0f},diffuseLight[]={1.0f,0.9f,0.8f,1.0f},lightPosition[]={.0f,.0f,2.0f,1.0f};
GLuint texture[6];

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

bool loadTexture(char *bitmap, int number)
{	
	FILE *file=fopen(bitmap,"r");
	if(!file)return false;
	fclose(file);
	AUX_RGBImageRec *textureImg[1];
	memset(textureImg,0,sizeof(void *)*1);
	if(!(textureImg[0]=auxDIBImageLoad(bitmap)))return false;
	glBindTexture(GL_TEXTURE_2D,texture[number]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
	//glTexImage2D(GL_TEXTURE_2D,0,3,textureImg[0]->sizeX,textureImg[0]->sizeY,0,GL_RGB,GL_UNSIGNED_BYTE,textureImg[0]->data);
	gluBuild2DMipmaps(GL_TEXTURE_2D,3,textureImg[0]->sizeX,textureImg[0]->sizeY,GL_RGB,GL_UNSIGNED_BYTE,textureImg[0]->data);
	free(textureImg[0]->data);
	free(textureImg[0]);
	return true;
}


GLvoid resizeScene(GLsizei width, GLsizei height)
{	if(height==0)height=1;
	glViewport(0,0,width,height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,.1f,100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int initGL(GLvoid)
{	glEnable(GL_TEXTURE_2D);
	glGenTextures(1,&texture[0]);	// 1 texture
	if(!loadTexture("data/glass.bmp",0))return false;
	glShadeModel(GL_SMOOTH);
	glClearColor(.0f,.0f,.0f,.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
//	Lighting
	glLightfv(GL_LIGHT1,GL_AMBIENT,ambientLight);
	glLightfv(GL_LIGHT1,GL_DIFFUSE,diffuseLight);
	glLightfv(GL_LIGHT1,GL_POSITION,lightPosition);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);
//	Blending
	glColor4f(1.0f,1.0f,1.0f,.5f); //50%
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	return true;
}

int drawScene(GLvoid)
{	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glTranslatef(.0f,.0f,z);
	glRotatef(xrot,1.0f,.0f,.0f);
	glRotatef(yrot,.0f,1.0f,.0f);
	glRotatef(zrot,.0f,.0f,1.0f);

	glBindTexture(GL_TEXTURE_2D,texture[0]);

	glBegin(GL_QUADS);
	glNormal3f(.0f,.0f,1.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(-1.0f,-1.0f,1.0f);	//front
	glTexCoord2f(1.0f,.0f); glVertex3f(1.0f,-1.0f, 1.0f);
	glTexCoord2f(1.0f,1.0f); glVertex3f(1.0f,+1.0f, 1.0f);
	glTexCoord2f(.0f,1.0f); glVertex3f(-1.0f,+1.0f,1.0f);

	glNormal3f(1.0f,.0f,.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(1.0f,-1.0f,1.0f);	//right
	glTexCoord2f(1.0f,0.0f); glVertex3f(1.0f,-1.0f,-1.0f);
	glTexCoord2f(1.0f,1.0f); glVertex3f(1.0f,1.0f,-1.0f);
	glTexCoord2f(0.0f,1.0f); glVertex3f(1.0f,1.0f,1.0f);

	glNormal3f(.0f,.0f,-1.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(1.0f,-1.0f,-1.0f);	//back
	glTexCoord2f(2.0f,0.0f); glVertex3f(-1.0f,-1.0f,-1.0f);
	glTexCoord2f(2.0f,2.0f); glVertex3f(-1.0f,1.0f,-1.0f);
	glTexCoord2f(0.0f,2.0f); glVertex3f(1.0f,1.0f,-1.0f);

	glNormal3f(-1.0f,.0f,.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(-1.0f,-1.0f,-1.0f);	//left
	glTexCoord2f(1.0f,0.0f); glVertex3f(-1.0f,-1.0f,+1.0f);
	glTexCoord2f(1.0f,1.0f); glVertex3f(-1.0f,1.0f,+1.0f);
	glTexCoord2f(0.0f,1.0f); glVertex3f(-1.0f,1.0f,-1.0f);

	glNormal3f(.0f,-1.0f,.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(-1.0f,-1.0f,-1.0f);	//bottom	
	glTexCoord2f(1.0f,0.0f); glVertex3f(-1.0f,-1.0f,+1.0f);
	glTexCoord2f(1.0f,1.0f); glVertex3f(+1.0f,-1.0f,1.0f);
	glTexCoord2f(0.0f,1.0f); glVertex3f(1.0f,-1.0f,-1.0f);

	glNormal3f(.0f,1.0f,.0f);
	glTexCoord2f(0.0f,0.0f); glVertex3f(-1.0f,1.0f,+1.0f);	//top
	glTexCoord2f(1.0f,0.0f); glVertex3f(1.0f,1.0f,+1.0f);
	glTexCoord2f(1.0f,1.0f); glVertex3f(1.0f,1.0f,-1.0f);
	glTexCoord2f(0.0f,1.0f); glVertex3f(-1.0f,1.0f,-1.0f);
	glEnd();

//	xrot+=a; if(xrot>30 || xrot<-30)a=-a;
//	yrot-=1.5f;
//	zrot-=0.0f;

	return true;
}

GLvoid closeWindow(GLvoid)
{
	if(fullscreen){
		ChangeDisplaySettings(NULL,0);
		ShowCursor(true);
	}
	if(hRC){
		if(!wglMakeCurrent(NULL,NULL))MessageBox(NULL,"Couldn't release DC and RC","Error",MB_OK|MB_ICONINFORMATION);
		if(!wglDeleteContext(hRC))MessageBox(NULL,"Couldn't release rendering context","Error",MB_OK|MB_ICONINFORMATION);
		hRC=NULL;
	}
	if(hDC&&!ReleaseDC(hWnd,hDC)){
		MessageBox(NULL,"Couldn't release device context","Error",MB_OK|MB_ICONINFORMATION);
		hDC=NULL;
	}
	if(hWnd&&!DestroyWindow(hWnd)){
		MessageBox(NULL,"Couldn't destroy window","Error",MB_OK|MB_ICONINFORMATION);
		hWnd=NULL;
	}
	if(!UnregisterClass("OpenGL",hInstance)){
		MessageBox(NULL,"Couldn't unregister class 'OpenGL'","Error",MB_OK|MB_ICONINFORMATION);
		hInstance=NULL;
	}
}

BOOL createWindow(char* caption, int width, int height, int bits)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values

	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height


	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=false;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return false;
			}
		}
	}

	if (fullscreen)
	{
		dwExStyle=WS_EX_APPWINDOW;
		dwStyle=WS_POPUP;
		ShowCursor(false);
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle=WS_OVERLAPPEDWINDOW;
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								caption,							// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		closeWindow();
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))
	{
		closeWindow();
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))
	{
		closeWindow();
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))
	{
		closeWindow();
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				
	{
		closeWindow();
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					
	{
		closeWindow();								
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								
	}

	ShowWindow(hWnd,SW_SHOW);						
	SetForegroundWindow(hWnd);						
	SetFocus(hWnd);									
	resizeScene(width, height);						

	if (!initGL())									
	{
		closeWindow();								
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								
	}

	return true;									
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)		
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
			if (!HIWORD(wParam))active=true; else active=false;
			return 0;								// Return To The Message Loop

		case WM_SYSCOMMAND:							// Intercept System Commands
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit

		case WM_CLOSE:								// Did We Receive A Close Message?
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back

		case WM_KEYDOWN:							// Is A Key Being Held Down?
			keys[wParam] = true;					// If So, Mark It As TRUE
			return 0;								// Jump Back

		case WM_KEYUP:								// Has A Key Been Released?
			keys[wParam] = false;					// If So, Mark It As FALSE
			return 0;								// Jump Back

		case WM_SIZE:								// Resize The OpenGL Window
			resizeScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
	}

	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{			
	MSG		msg;									// Windows Message Structure
	BOOL	done=false;								// Bool Variable To Exit Loop

	MessageBox(NULL,"How to use:\n\
[F1] toggles fullscreen mode / windowed mode\n\
[<-] rotate left\n\
[->] rotate right\n\
[Cursor UP] rotate up\n\
[Cursor DOWN] rotate down\n\
[A] move to the object\n\
[Z] move back\n\
[L] lighting on/off\n\
[B] Blending on/off\n\
[ESC] exit\n","Instructions:",MB_OK|MB_ICONINFORMATION);
	
	if (MessageBox(NULL,"Start fullscreen?", "Start fullscreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)fullscreen=false;else fullscreen=true;							

	if (!createWindow("OpenGL Test",XRES,YRES,16))return 0;
	
	while(!done)									
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	
		{
			if (msg.message==WM_QUIT)				
			{	done=true;
			}
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else										
		{
			
			if (active){
				if (keys[VK_ESCAPE]){
					done=true;						// ESC Signalled A Quit
				}
				else								// Not Time To Quit, Update Screen
				{
					drawScene();					// Draw The Scene
					SwapBuffers(hDC);				// Swap Buffers (Double Buffering)
				}
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=false;					// If So Make Key FALSE
				closeWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!createWindow("OpenGL Test",XRES,YRES,16))
				{
					return 0;						// Quit If Window Was Not Created
				}
			}

			if(keys['L']&&!lp){
				lp=true;
				light=!light;
				if(light)glEnable(GL_LIGHTING);else glDisable(GL_LIGHTING);
			}
			if(!keys['L'])lp=false;
			
			if(keys['B']&&!bp){
				bp=true;
				blend=!blend;
				if(blend){glEnable(GL_BLEND);glDisable(GL_DEPTH_TEST);}
				else{glDisable(GL_BLEND);glEnable(GL_DEPTH_TEST);}
			}
			if(!keys['B'])bp=false;

			if(keys[VK_UP])xrot+=1.0f;
			if(keys[VK_DOWN])xrot-=1.0f;
			if(keys[VK_LEFT])yrot+=1.0f;
			if(keys[VK_RIGHT])yrot-=1.0f;
			if(keys['A'])z+=.1f;
			if(keys['Z'])z-=.1f;
			
		}
	}

	// Shutdown
	closeWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
